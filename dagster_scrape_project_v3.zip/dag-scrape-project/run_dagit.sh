DAGSTER_HOME=/home/dmytro_fedoru/dagster-dbt/dag-scrape-project/dagit_logs dagit -h 0.0.0.0 -p 8080
