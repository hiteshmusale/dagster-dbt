
export GOOGLE_APPLICATION_CREDENTIALS="/home/dmytro_fedoru/.dbt/keyfile.json"

